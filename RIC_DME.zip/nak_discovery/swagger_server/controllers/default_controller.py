import json
import os
import connexion
import logging
from flask import jsonify
from swagger_server.models.dme_type_related_capabilities import DmeTypeRelatedCapabilities
from swagger_server.models.problem_details import ProblemDetails
from swagger_server.models.dme_type_id import DmeTypeId

# 로깅 설정
logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")

DB_FILE = "/usr/src/app/shared_data/capabilities_db.json"

def load_db():
    """JSON 파일에서 데이터를 로드"""
    if os.path.exists(DB_FILE):
        try:
            with open(DB_FILE, "r") as f:
                data = json.load(f)
                logging.info(f"DB 로드 성공: {len(data)}개의 항목")
                return data
        except Exception as e:
            logging.error(f"DB 로드 중 오류 발생: {e}")
            logging.debug(f"오류 발생 위치: {e.__traceback__}")
            return {}

    else:
        logging.warning("DB 파일이 존재하지 않음. 빈 데이터 반환")
        return {}

def save_db(data):
    """데이터를 JSON 파일에 저장"""
    try:
        with open(DB_FILE, "w") as f:
            json.dump(data, f)
        logging.info(f"DB 저장 완료: {len(data)}개의 항목")
    except Exception as e:
        logging.error(f"DB 저장 중 오류 발생: {e}")

def dme_types_dme_type_id_get(dme_type_id):  # noqa: E501
    """dme_types_dme_type_id_get
    특정 DME 타입 ID 정보를 가져오기
    """
    logging.info(f"요청된 DME 타입 ID: {dme_type_id}")
    
    # namespace:name:version 형식으로 분리
    try:
        namespace, name, version = dme_type_id.split(":")
    except ValueError:
        logging.error("잘못된 형식의 dme_type_id")
        return jsonify({"message": "Invalid dme_type_id format. Expected 'namespace:name:version'."}), 400

    db_data = load_db()

    # 데이터베이스에서 해당 DME 타입을 검색
    for key, value in db_data.items():
        dme_type = value.get('dme_type_definition', {}).get('dme_type_id', {})
        if (dme_type.get('name') == name and
            dme_type.get('namespace') == namespace and
            dme_type.get('version') == version):
            return jsonify(value), 200
    
    logging.warning(f"해당 DME 타입 ID를 찾을 수 없음: {dme_type_id}")
    problem_details = ProblemDetails(type="https://example.com/problem-type", title="DME Type ID Not Found", status=404)
    return jsonify(problem_details.to_dict()), 404


def dme_types_get(identity_namespace=None, identity_name=None, data_category=None):  # noqa: E501
    """dme_types_get
    등록된 DME 타입 목록 조회
    """
    logging.info(f"DME 타입 목록 조회 요청 - namespace: {identity_namespace}, name: {identity_name}, data_category: {data_category}")
    
    db_data = load_db()
    
    dme_types = [value for value in db_data.values()]
    
    # # 필터링
    # if identity_namespace:
    #     dme_types = [d for d in dme_types if d['dmeTypeDefinition']['namespace'] == identity_namespace]
    # if identity_name:
    #     dme_types = [d for d in dme_types if d['dmeTypeDefinition']['name'] == identity_name]
    # if data_category:
    #     dme_types = [d for d in dme_types if 'dataCategory' in d['metadata'] and all(category in d['metadata']['dataCategory'] for category in data_category)]
    
    logging.info(f"조회된 DME 타입 개수: {len(dme_types)}")
    
    return dme_types, 200
