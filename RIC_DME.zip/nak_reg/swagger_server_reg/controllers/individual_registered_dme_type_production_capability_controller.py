import json
import os
import connexion
import logging
from swagger_server_reg.models.dme_type_related_capabilities import DmeTypeRelatedCapabilities  # noqa: E501
from swagger_server_reg.models.problem_details import ProblemDetails  # noqa: E501
from swagger_server_reg.models.registration_id import RegistrationId  # noqa: E501
from swagger_server_reg import util

# 로깅 설정
logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")

DB_FILE = "/usr/src/app/shared_data/capabilities_db.json"  # DB 파일 경로

def load_db():
    """JSON 파일에서 데이터를 로드"""
    if os.path.exists(DB_FILE):
        try:
            with open(DB_FILE, "r") as f:
                data = json.load(f)
                logging.info(f"DB 로드 성공: {len(data)}개의 항목")
                return data
        except Exception as e:
            logging.error(f"DB 로드 중 오류 발생: {e}")
            return {}
    else:
        logging.warning("DB 파일이 존재하지 않음. 빈 데이터 반환")
        return {}

def save_db(data):
    """데이터를 JSON 파일에 저장"""
    try:
        with open(DB_FILE, "w") as f:
            json.dump(data, f)
        logging.info(f"DB 저장 완료: {len(data)}개의 항목")
    except Exception as e:
        logging.error(f"DB 저장 중 오류 발생: {e}")

def delete_production_capabilities_by_id(registration_id):
    """등록된 registration_id로 생산 능력 데이터를 삭제"""
    db_data = load_db()
    if registration_id in db_data:
        del db_data[registration_id]  # 해당 ID의 데이터를 삭제
        save_db(db_data)  # 변경된 데이터 저장
        return True
    return False

def production_capabilities_registration_id_delete(registration_id):  # noqa: E501
    """production_capabilities_registration_id_delete

    To deregister DME type production capabilities

    :param registration_id: 
    :type registration_id: str

    :rtype: None
    """
    try:
        # 실제 삭제 작업 수행
        deleted = delete_production_capabilities_by_id(registration_id)
        if deleted:
            return {"message": "Production capabilities deleted successfully"}, 204
        else:
            return {"error": "Not found"}, 404
    except Exception as e:
        return {"error": f"Internal Server Error: {str(e)}"}, 500

def get_production_capabilities_by_id(registration_id):
    """등록된 registration_id로 생산 능력 데이터를 조회"""
    db_data = load_db()
    return db_data.get(registration_id)

def production_capabilities_registration_id_get(registration_id):  # noqa: E501
    """production_capabilities_registration_id_get

    To query DME type production capabilities that it has previously registered

    :param registration_id: The ID used for querying production capabilities
    :type registration_id: str

    :rtype: DmeTypeRelatedCapabilities
    """
    try:
        # registration_id가 None 또는 잘못된 형식이면 오류 반환
        if not registration_id:
            return {"error": "Invalid registration_id"}, 400

        # 실제 조회 로직 실행
        production_capability = get_production_capabilities_by_id(registration_id)

        if production_capability:
            # DmeTypeRelatedCapabilities 객체로 변환 후 반환
            return production_capability, 200
        else:
            return {"error": "Not found"}, 404
    except Exception as e:
        return {"error": f"Internal Server Error: {str(e)}"}, 500

def update_production_capabilities_by_id(registration_id, body):
    """등록된 registration_id로 생산 능력 데이터를 업데이트"""
    db_data = load_db()
    if registration_id not in db_data:
        return None  # 데이터가 없으면 None 반환
    
    existing_data = db_data[registration_id]
    
    # 기존 데이터를 업데이트
    existing_data.update(body)  # 기존 데이터에 새 데이터를 덮어씀
    
    # 업데이트된 데이터를 다시 저장
    db_data[registration_id] = existing_data
    save_db(db_data)  # 변경된 데이터 저장
    
    return existing_data

def production_capabilities_registration_id_put(registration_id, body):  # noqa: E501
    """production_capabilities_registration_id_put

    To update DME type production capabilities that it has previously registered

    :param registration_id: 
    :type registration_id: str
    :param body: 
    :type body: dict | bytes

    :rtype: dict
    """
    try:
        # 실제 업데이트 작업 수행
        updated = update_production_capabilities_by_id(registration_id, body)
        if updated:
            return updated, 200
        else:
            return {"error": "Not found"}, 404
    except Exception as e:
        return {"error": f"Internal Server Error: {str(e)}"}, 500
