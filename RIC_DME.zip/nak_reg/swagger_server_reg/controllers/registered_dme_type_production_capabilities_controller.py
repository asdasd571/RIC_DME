import json
import os
import connexion
import uuid
import logging
from swagger_server_reg.models.dme_type_related_capabilities import DmeTypeRelatedCapabilities  # noqa: E501
from swagger_server_reg import util

# 로깅 설정
logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")

DB_FILE = "/usr/src/app/shared_data/capabilities_db.json"

# 임시 저장소: 나중에 데이터를 DB로 변경할 때는 여기를 DB로 수정
capabilities_db = {}

def load_db():
    """JSON 파일에서 데이터를 로드"""
    if os.path.exists(DB_FILE):
        try:
            with open(DB_FILE, "r") as f:
                data = json.load(f)
                logging.info(f"DB 로드 성공: {len(data)}개의 항목")
                return data
        except Exception as e:
            logging.error(f"DB 로드 중 오류 발생: {e}")
            return {}
    else:
        logging.warning("DB 파일이 존재하지 않음. 빈 데이터 반환")
        return {}

def save_db(data):
    """데이터를 JSON 파일에 저장"""
    try:
        with open(DB_FILE, "w") as f:
            json.dump(data, f)
        logging.info(f"DB 저장 완료: {len(data)}개의 항목")
    except Exception as e:
        logging.error(f"DB 저장 중 오류 발생: {e}")

def production_capabilities_post(body):  # noqa: E501
    """production_capabilities_post

    DME 타입의 생산 능력을 등록하는 엔드포인트

    :param body: JSON 형식으로 전달된 생산 능력 데이터
    :type body: dict | bytes

    :rtype: dict (등록된 registration_id 반환)
    """
    logging.info("생산 능력 등록 요청 수신")
    
    if not connexion.request.is_json:
        logging.warning("잘못된 입력: JSON 형식이 아님")
        return {'message': 'Invalid input, JSON expected.'}, 400

    # 클라이언트로부터 받은 JSON 데이터를 객체로 변환
    body = DmeTypeRelatedCapabilities.from_dict(connexion.request.get_json())  # noqa: E501
    logging.info(f"입력 데이터: {body}")

    # 새로운 registration_id 생성 (예: UUID 사용)
    registration_id = str(uuid.uuid4())  # 고유한 ID 생성
    logging.info(f"생성된 registration_id: {registration_id}")

    # body 객체에 registration_id 추가
    body.registration_id = registration_id  # 객체에 ID 추가

    # 현재 DB 로드
    capabilities_db = load_db()

    # 임시 저장소에 데이터 저장
    capabilities_db[registration_id] = body.to_dict()  # registration_id를 키로 사용하여 저장

    # JSON 파일에 저장
    save_db(capabilities_db)
    logging.info(f"생산 능력 등록 완료: {registration_id}")

    # 등록된 ID와 함께 응답 반환
    return {
        "registration_id": registration_id,
        "message": "Production capability registered successfully"
    }, 201  # 201 Created